# Replace with your Workspace ID
$CustomerId = "b5618e86-1ccb-4212-8ba6-e4af4065877a"  

# Replace with your Primary Key
$SharedKey = "E1Od5L+SMUHl7JbBqz3pF7DLpcsk6sHGSdaxPZ5ICJVfa5df+R4eGjtwfs8ggnxiaweMEbdz6Xqvmu5ZRmaMyA=="

# Specify the name of the record type that you'll be creating
$LogType = "HistoricKPIsTimer_CL"

# You can use an optional field to specify the timestamp from the data. If the time field is not specified, Azure Monitor assumes the time is the message ingestion time
$TimeStampField = ""


# Create the function to create the authorization signature
Function Build-Signature ($customerId, $sharedKey, $date, $contentLength, $method, $contentType, $resource)
{
    $xHeaders = "x-ms-date:" + $date
    $stringToHash = $method + "`n" + $contentLength + "`n" + $contentType + "`n" + $xHeaders + "`n" + $resource

    $bytesToHash = [Text.Encoding]::UTF8.GetBytes($stringToHash)
    $keyBytes = [Convert]::FromBase64String($sharedKey)

    $sha256 = New-Object System.Security.Cryptography.HMACSHA256
    $sha256.Key = $keyBytes
    $calculatedHash = $sha256.ComputeHash($bytesToHash)
    $encodedHash = [Convert]::ToBase64String($calculatedHash)
    $authorization = 'SharedKey {0}:{1}' -f $customerId,$encodedHash
    return $authorization
}


# Create the function to create and post the request
Function Post-LogAnalyticsData($customerId, $sharedKey, $body, $logType)
{
    $method = "POST"
    $contentType = "application/json"
    $resource = "/api/logs"
    $rfc1123date = [DateTime]::UtcNow.ToString("r")
    $contentLength = $body.Length
    $signature = Build-Signature `
        -customerId $customerId `
        -sharedKey $sharedKey `
        -date $rfc1123date `
        -contentLength $contentLength `
        -method $method `
        -contentType $contentType `
        -resource $resource
    $uri = "https://" + $customerId + ".ods.opinsights.azure.com" + $resource + "?api-version=2016-04-01"

    $headers = @{
        "Authorization" = $signature;
        "Log-Type" = $logType;
        "x-ms-date" = $rfc1123date;
        "time-generated-field" = $TimeStampField;
    }

    $response = Invoke-WebRequest -Uri $uri -Method $method -ContentType $contentType -Headers $headers -Body $body -UseBasicParsing
    return $response.StatusCode

}

# Submit the data to the API endpoint
#Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json)) -logType $logType


# TRADE

Write-Output "Premium Storage account dev & sandbox:"
$json1=Search-AzGraph "Resources | where type == 'microsoft.storage/storageaccounts' | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,3) in ('gts')) | project id,name,subscriptionId) on subscriptionId| where sku startswith 'Premium' and ((substring(name,3,1) == 'd') or (substring(name,3,1) == 's'))| summarize Value=tostring(count()) | extend TypeData='PremiumStorageAccountsDevSandbox' | extend Vertical='Trade'" | ConvertTo-Json
# Write-Output $json1

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json1)) -logType $logType

Write-Output "Premium Snapshots dev & sandbox:"
$json2=Search-AzGraph "Resources | where type=='microsoft.compute/snapshots'| join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,4) in ('gtsd','gtss')) | project id,name,subscriptionId) on subscriptionId| where sku contains ('Premium') | summarize Value=tostring(count()) | extend TypeData='PremiumSnapshotsDevSandbox' | extend Vertical='Trade'" | ConvertTo-Json
# Write-Output $json2

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json2)) -logType $logType

Write-Output "Premium Managed Disks dev & sandbox:"
$json3=Search-AzGraph "Resources | where type=='microsoft.compute/disks'| join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,4) in ('gtsd','gtss')) | project id,name,subscriptionId) on subscriptionId| where sku contains ('Premium') | summarize Value=tostring(count()) | extend TypeData='PremiumManagedDisksDevSandbox' | extend Vertical='Trade'" | ConvertTo-Json
# Write-Output $json3

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json3)) -logType $logType

Write-Output "Storage accounts with redundancy (GRS, ZRS, RA-GRS, RA-GZRS) dev & sandbox:"
$json4=Search-AzGraph "Resources| where type == 'microsoft.storage/storageaccounts' | join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,4) in ('gtsd','gtss')) | project id,subscription = name,subscriptionId) on subscriptionId| where ((sku contains 'GRS') or (sku contains 'GZRS') or (sku contains 'ZRS'))| summarize Value=tostring(count()) | extend TypeData='StorageRedundancyDevSandbox' | extend Vertical='Trade'" | ConvertTo-Json
# Write-Output $json4

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json4)) -logType $logType

Write-Output "Snapshots with redundancy (GRS, ZRS, RA-GRS, RA-GZRS) dev & sandbox:"
$json5=Search-AzGraph "Resources | extend timeCreated = todatetime(properties.['timeCreated']) | extend diff = tolong(format_timespan(now()-timeCreated, 'ddd')) | where type=='microsoft.compute/snapshots' and diff > 31 | join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,4) in ('gtsd','gtss')) | project id,name,subscriptionId) on subscriptionId| where sku contains ('ZRS') or sku contains ('GRS') or sku contains ('GZRS')| summarize Value=tostring(count()) | extend TypeData='SnapshotRedundancyDevSandbox' | extend Vertical='Trade'" | ConvertTo-Json
# Write-Output $json5

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json5)) -logType $logType

Write-Output "Managed disks with redundancy:"
$json6=Search-AzGraph "Resources| where type == 'microsoft.compute/disks' | join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,4) in ('gtsd','gtss')) | project id,subscription = name,subscriptionId) on subscriptionId| where ((sku contains 'GRS') or (sku contains 'GZRS') or (sku contains 'ZRS'))| summarize Value=tostring(count()) | extend TypeData='ManagedDiskRedundancyDevSandbox' | extend Vertical='Trade'" | ConvertTo-Json
# Write-Output $json6

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json6)) -logType $logType

Write-Output "Unattached Managed Disks:"
$json7=Search-AzGraph "Resources | where type=='microsoft.compute/disks'| join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,3) in ('gts')) | project id,subscription = name,subscriptionId) on subscriptionId| project name,type,tenantId,resourceGroup,subscription,relatedTo=case(isnotempty(managedBy),managedBy,'N/A'),diskstate=tostring(properties['diskState']) | where relatedTo == 'N/A' and diskstate == 'Unattached' | where (substring(subscription,0,3) in ('gts') and substring(name,0,6) != ('azure-') and substring(name,0,6) != ('ocp02-') and substring(name,0,11) != ('kubernetes-')  or substring(subscription,0,3) in ('gms','pgx','ssd')) | summarize Value=tostring(count()) | extend TypeData='UnattachedManagedDisks' | extend Vertical='Trade'" | ConvertTo-Json
# Write-Output $json7

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json7)) -logType $logType

Write-Output "Orphaned Static public Ips"
$json8=Search-AzGraph "Resources | where type=='microsoft.network/publicipaddresses' | join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,3) in ('gts')) | project id,name,subscriptionId) on subscriptionId| project name,type,location,resourceGroup,name1,subscriptionId,managedBy,allocation=properties.publicIPAllocationMethod,ipConfig=properties.ipConfiguration.id | where isempty(ipConfig) and tostring(allocation)=='Static'| summarize Value=tostring(count()) | extend TypeData='OrphanedStaticPublicIps' | extend Vertical='Trade'" | ConvertTo-Json
# Write-Output $json8

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json8)) -logType $logType

# CONSUMER

Write-Output "Premium Storage accounts:" 
$json9=Search-AzGraph "Resources | where type == 'microsoft.storage/storageaccounts' | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,3) in ('pgxd','pgxs','ssdd','ssds')) | project id,name,subscriptionId) on subscriptionId| where sku startswith 'Premium' | summarize Value=tostring(count()) | extend TypeData='PremiumStorageAccountsDevSandbox' | extend Vertical='Consumer'" | ConvertTo-Json
# Write-Output $json9

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json9)) -logType $logType

Write-Output "Premium Snapshots dev & sandbox:"
$json10=Search-AzGraph "Resources | where type=='microsoft.compute/snapshots'| join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,4) in ('pgxd','pgxs','ssdd','ssds')) | project id,name,subscriptionId) on subscriptionId| where sku contains ('Premium') | summarize Value=tostring(count()) | extend TypeData='PremiumSnapshotsDevSandbox' | extend Vertical='Consumer'" | ConvertTo-Json
# Write-Output $json10

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json10)) -logType $logType

Write-Output "Premium Managed Disks:"
$json11=Search-AzGraph "Resources | where type=='microsoft.compute/disks'| join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,4) in ('pgxd','pgxs','ssdd','ssds')) | project id,name,subscriptionId) on subscriptionId| where sku contains ('Premium') | summarize Value=tostring(count()) | extend TypeData='PremiumManagedDisksDevSandbox' | extend Vertical='Consumer'" | ConvertTo-Json
# Write-Output $json11

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json11)) -logType $logType

Write-Output "Storage accounts with redundancy (GRS, ZRS, RA-GRS, RA-GZRS) dev & sandbox:"
$json12=Search-AzGraph "Resources| where type == 'microsoft.storage/storageaccounts' | join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,4) in ('pgxd','pgxs','ssdd','ssds')) | project id,subscription = name,subscriptionId) on subscriptionId| where ((sku contains 'GRS') or (sku contains 'GZRS') or (sku contains 'ZRS'))| summarize Value=tostring(count()) | extend TypeData='StorageRedundancyDevSandbox' | extend Vertical='Consumer'" | ConvertTo-Json
# Write-Output $json12

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json12)) -logType $logType

Write-Output "Snapshots with redundancy (GRS, ZRS, RA-GRS, RA-GZRS):"
$json13=Search-AzGraph "Resources | extend timeCreated = todatetime(properties.['timeCreated']) | extend diff = tolong(format_timespan(now()-timeCreated, 'ddd')) | where type=='microsoft.compute/snapshots' and diff > 31 | join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,4) in ('pgxd','pgxs','ssdd','ssds')) | project id,name,subscriptionId) on subscriptionId| where sku contains ('ZRS') or sku contains ('GRS') or sku contains ('GZRS')| summarize Value=tostring(count()) | extend TypeData='SnapshotRedundancyDevSandbox' | extend Vertical='Consumer'" | ConvertTo-Json
# Write-Output $json13

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json13)) -logType $logType

Write-Output "Managed disks with redundancy:"
$json14=Search-AzGraph "Resources| where type == 'microsoft.compute/disks' | join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,4) in ('pgx','ssd')) | project id,subscription = name,subscriptionId) on subscriptionId| where ((sku contains 'GRS') or (sku contains 'GZRS') or (sku contains 'ZRS'))| summarize Value=tostring(count()) | extend TypeData='ManagedDiskRedundancyDevSandbox' | extend Vertical='Consumer'" | ConvertTo-Json
# Write-Output $json14

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json14)) -logType $logType

Write-Output "Unattached Managed Disks:"
$json15=Search-AzGraph "Resources | where type=='microsoft.compute/disks'| join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,3) in ('pgx','ssd')) | project id,subscription = name,subscriptionId) on subscriptionId| project name,type,tenantId,resourceGroup,subscription,relatedTo=case(isnotempty(managedBy),managedBy,'N/A'),diskstate=tostring(properties['diskState']) | where relatedTo == 'N/A' and diskstate == 'Unattached'| summarize Value=tostring(count()) | extend TypeData='UnattachedManagedDisks' | extend Vertical='Consumer'" | ConvertTo-Json
# Write-Output $json15

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json15)) -logType $logType

Write-Output "Orphaned Static public Ips"
$json16=Search-AzGraph "Resources | where type=='microsoft.network/publicipaddresses' | join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,3) in ('pgx','ssd')) | project id,name,subscriptionId) on subscriptionId| project name,type,location,resourceGroup,name1,subscriptionId,managedBy,allocation=properties.publicIPAllocationMethod,ipConfig=properties.ipConfiguration.id | where isempty(ipConfig) and tostring(allocation)=='Static'| summarize Value=tostring(count()) | extend TypeData='OrphanedStaticPublicIps' | extend Vertical='Consumer'" | ConvertTo-Json
# Write-Output $json16

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json16)) -logType $logType


# MERCHANT

Write-Output "Premium Storage accounts:" 
$json17=Search-AzGraph "Resources | where type == 'microsoft.storage/storageaccounts' | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,3) in ('gms')) | project id,name,subscriptionId) on subscriptionId| where sku startswith 'Premium' and ((substring(name,3,1) == 'd') or (substring(name,3,1) == 's'))| summarize Value=tostring(count()) | extend TypeData='PremiumStorageAccountsDevSandbox' | extend Vertical='Merchant'" | ConvertTo-Json
# Write-Output $json17

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json17)) -logType $logType

Write-Output "Premium Snapshots dev & sandbox:"
$json18=Search-AzGraph "Resources | where type=='microsoft.compute/snapshots'| join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,4) in ('gmsd','gmss')) | project id,name,subscriptionId) on subscriptionId| where sku contains ('Premium') | summarize Value=tostring(count()) | extend TypeData='PremiumSnapshotsDevSandbox' | extend Vertical='Merchant'" | ConvertTo-Json
# Write-Output $json18

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json18)) -logType $logType

Write-Output "Premium Managed Disks:"
$json19=Search-AzGraph "Resources | where type=='microsoft.compute/disks'| join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,4) in ('gmsd','gmss')) | project id,name,subscriptionId) on subscriptionId| where sku contains ('Premium') | summarize Value=tostring(count()) | extend TypeData='PremiumManagedDisksDevSandbox' | extend Vertical='Merchant'" | ConvertTo-Json
# Write-Output $json19

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json19)) -logType $logType

Write-Output "Storage accounts with redundancy (GRS, ZRS, RA-GRS, RA-GZRS) dev & sandbox:"
$json20=Search-AzGraph "Resources| where type == 'microsoft.storage/storageaccounts' | join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,4) in ('gmsd','gmss')) | project id,subscription = name,subscriptionId) on subscriptionId| where ((sku contains 'GRS') or (sku contains 'GZRS') or (sku contains 'ZRS'))| summarize Value=tostring(count()) | extend TypeData='StorageRedundancyDevSandbox' | extend Vertical='Merchant'" | ConvertTo-Json
# Write-Output $json20

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json20)) -logType $logType

Write-Output "Snapshots with redundancy (GRS, ZRS, RA-GRS, RA-GZRS):"
$json21=Search-AzGraph "Resources | extend timeCreated = todatetime(properties.['timeCreated']) | extend diff = tolong(format_timespan(now()-timeCreated, 'ddd')) | where type=='microsoft.compute/snapshots' and diff > 31 | join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,4) in ('gmsd','gmss')) | project id,name,subscriptionId) on subscriptionId| where sku contains ('ZRS') or sku contains ('GRS') or sku contains ('GZRS')| summarize Value=tostring(count()) | extend TypeData='SnapshotRedundancyDevSandbox' | extend Vertical='Merchant'" | ConvertTo-Json
# Write-Output $json21

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json21)) -logType $logType

Write-Output "Managed disks with redundancy:"
$json22=Search-AzGraph "Resources| where type == 'microsoft.compute/disks' | join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,4) in ('gmsd','gmss')) | project id,subscription = name,subscriptionId) on subscriptionId| where ((sku contains 'GRS') or (sku contains 'GZRS') or (sku contains 'ZRS'))| summarize Value=tostring(count()) | extend TypeData='ManagedDiskRedundancyDevSandbox' | extend Vertical='Merchant'" | ConvertTo-Json
# Write-Output $json22

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json22)) -logType $logType

Write-Output "Unattached Managed Disks:"
$json23=Search-AzGraph "Resources | where type=='microsoft.compute/disks'| join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,3) in ('gms')) | project id,subscription = name,subscriptionId) on subscriptionId| project name,type,tenantId,resourceGroup,subscription,relatedTo=case(isnotempty(managedBy),managedBy,'N/A'),diskstate=tostring(properties['diskState']) | where relatedTo == 'N/A' and diskstate == 'Unattached' | where (substring(subscription,0,3) in ('gms') and (name !contains 'aks') and (name !startswith 'kubernetes-')) | summarize Value=tostring(count()) | extend TypeData='UnattachedManagedDisks' | extend Vertical='Merchant'" | ConvertTo-Json
# Write-Output $json23

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json23)) -logType $logType

Write-Output "Orphaned Static public Ips"
$json24=Search-AzGraph "Resources | where type=='microsoft.network/publicipaddresses' | join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,3) in ('gms')) | project id,name,subscriptionId) on subscriptionId| project name,type,location,resourceGroup,name1,subscriptionId,managedBy,allocation=properties.publicIPAllocationMethod,ipConfig=properties.ipConfiguration.id | where isempty(ipConfig) and tostring(allocation)=='Static'| summarize Value=tostring(count()) | extend TypeData='OrphanedStaticPublicIps' | extend Vertical='Merchant'" | ConvertTo-Json
# Write-Output $json24

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json24)) -logType $logType


Write-Output "Hybrid Benefit VM Windows"
$json25=Search-AzGraph "Resources | where type == 'microsoft.compute/virtualmachines' | join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where substring(name,0,4) in ('gmsi','gmsp','gtsi','gtsp','pgxi','ssdi','pgxp','ssdp') | project id,subscription = name,subscriptionId) on subscriptionId | extend Vertical=case(substring(name,0,3) in ('pgx','ssd'),'Consumer', case(substring(name,0,3)=='gms','Merchant','Trade')) | extend licenseType=tostring(properties['licenseType']) | extend os =case(properties.storageProfile.osDisk.osType=~ 'Windows','Windows',properties.storageProfile.osDisk.osType=~ 'Linux','Linux','-') | extend TypeData = case((licenseType in ('Windows_Server','Windows_Client','RHEL_BYOS','SLES_BYOS')),'Hybrid Benefit Activated','Hybrid Benefit Not activated') | where os=='Windows' | summarize Value=tostring(count()) by TypeData, Vertical" | ConvertTo-Json

Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($json25)) -logType $logType

# | where  SubName matches regex @'^gms'
# | where  SubName matches regex @'^gts'
# | where  SubName matches regex @'^sdi' or SubName matches regex @'^pgx' or SubName matches regex @'^ssd' or SubName matches regex @'^gpl'
# | where  SubName matches regex @'^pgx' or SubName matches regex @'^ssd'

# TRADE
Write-Output "Count of all my Azure resources"
$jsonKPIs=Search-AzGraph "Resources | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | project SubName=name, subscriptionId) on subscriptionId | where  SubName matches regex @'^gms' | project type, name, SubName,resourceGroup | summarize Value=count(), TypeData='CountAllResources', Vertical='Trade'" | ConvertTo-Json
Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonKPIs)) -logType $logType

Write-Output "Virtual machines count (includes classic)"
$jsonKPIs=Search-AzGraph "Resources | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | project SubName=name, subscriptionId) on subscriptionId | where  SubName matches regex @'^gms' | where type == 'microsoft.compute/virtualmachines' or type=='microsoft.classiccompute/virtualmachines' | summarize VMCount=count() | extend ['Count (Virtual Machines)']=VMCount | project Value=['Count (Virtual Machines)'], TypeData='CountVMs', Vertical='Trade'" | ConvertTo-Json
Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonKPIs)) -logType $logType

Write-Output "Count of SQL databases"
$jsonKPIs=Search-AzGraph "Resources | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | project SubName=name, subscriptionId) on subscriptionId | where  SubName matches regex @'^gms' | where type == 'microsoft.sql/servers/databases' | summarize Value=count(), TypeData='CountSQLDatabases', Vertical='Trade'" | ConvertTo-Json
Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonKPIs)) -logType $logType

Write-Output "Count of virtual networks (includes classic)"
$jsonKPIs=Search-AzGraph "Resources | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | project SubName=name, subscriptionId) on subscriptionId | where  SubName matches regex @'^gms' | where type == 'microsoft.network/virtualnetworks' or type == 'microsoft.classicnetwork/virtualnetworks' | summarize Value=count(), TypeData='CountVirtualNetworks', Vertical='Trade'" | ConvertTo-Json
Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonKPIs)) -logType $logType

Write-Output "Total public IPs"
$jsonKPIs=Search-AzGraph "Resources | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | project SubName=name, subscriptionId) on subscriptionId | where  SubName matches regex @'^gms' | where type == 'microsoft.network/publicipaddresses' | summarize Value=count(), TypeData='TotalPublicIP', Vertical='Trade'" | ConvertTo-Json
Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonKPIs)) -logType $logType

Write-Output "Sum of all disk sizes (GB)"
$jsonKPIs=Search-AzGraph "Resources | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | project SubName=name, subscriptionId) on subscriptionId | where  SubName matches regex @'^gms' | where type == 'microsoft.compute/disks' | extend SizeGB = tolong(properties.diskSizeGB) | summarize Value=sum(SizeGB), TypeData='SumAllDiskSize', Vertical='Trade'" | ConvertTo-Json
Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonKPIs)) -logType $logType



# CONSUMER
Write-Output "Count of all my Azure resources"
$jsonKPIs=Search-AzGraph "Resources | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | project SubName=name, subscriptionId) on subscriptionId | where  SubName matches regex @'^gts' | project type, name, SubName,resourceGroup | summarize Value=count(), TypeData='CountAllResources', Vertical='Consumer'" | ConvertTo-Json
Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonKPIs)) -logType $logType

Write-Output "Virtual machines count (includes classic)"
$jsonKPIs=Search-AzGraph "Resources | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | project SubName=name, subscriptionId) on subscriptionId | where  SubName matches regex @'^gts' | where type == 'microsoft.compute/virtualmachines' or type=='microsoft.classiccompute/virtualmachines' | summarize VMCount=count() | extend ['Count (Virtual Machines)']=VMCount | project Value=['Count (Virtual Machines)'], TypeData='CountVMs', Vertical='Consumer'" | ConvertTo-Json
Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonKPIs)) -logType $logType

Write-Output "Count of SQL databases"
$jsonKPIs=Search-AzGraph "Resources | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | project SubName=name, subscriptionId) on subscriptionId | where  SubName matches regex @'^gts' | where type == 'microsoft.sql/servers/databases' | summarize Value=count(), TypeData='CountSQLDatabases', Vertical='Consumer'" | ConvertTo-Json
Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonKPIs)) -logType $logType

Write-Output "Count of virtual networks (includes classic)"
$jsonKPIs=Search-AzGraph "Resources | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | project SubName=name, subscriptionId) on subscriptionId | where  SubName matches regex @'^gts' | where type == 'microsoft.network/virtualnetworks' or type == 'microsoft.classicnetwork/virtualnetworks' | summarize Value=count(), TypeData='CountVirtualNetworks', Vertical='Consumer'" | ConvertTo-Json
Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonKPIs)) -logType $logType

Write-Output "Total public IPs"
$jsonKPIs=Search-AzGraph "Resources | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | project SubName=name, subscriptionId) on subscriptionId | where  SubName matches regex @'^gts' | where type == 'microsoft.network/publicipaddresses' | summarize Value=count(), TypeData='TotalPublicIP', Vertical='Consumer'" | ConvertTo-Json
Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonKPIs)) -logType $logType

Write-Output "Sum of all disk sizes (GB)"
$jsonKPIs=Search-AzGraph "Resources | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | project SubName=name, subscriptionId) on subscriptionId | where  SubName matches regex @'^gts' | where type == 'microsoft.compute/disks' | extend SizeGB = tolong(properties.diskSizeGB) | summarize Value=sum(SizeGB), TypeData='SumAllDiskSize', Vertical='Consumer'" | ConvertTo-Json
Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonKPIs)) -logType $logType



# MERCHANT
Write-Output "Count of all my Azure resources"
$jsonKPIs=Search-AzGraph "Resources | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | project SubName=name, subscriptionId) on subscriptionId | where  SubName matches regex @'^pgx' or SubName matches regex @'^ssd' | project type, name, SubName,resourceGroup | summarize Value=count(), TypeData='CountAllResources', Vertical='Merchant'" | ConvertTo-Json
Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonKPIs)) -logType $logType

Write-Output "Virtual machines count (includes classic)"
$jsonKPIs=Search-AzGraph "Resources | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | project SubName=name, subscriptionId) on subscriptionId | where  SubName matches regex @'^pgx' or SubName matches regex @'^ssd' | where type == 'microsoft.compute/virtualmachines' or type=='microsoft.classiccompute/virtualmachines' | summarize VMCount=count() | extend ['Count (Virtual Machines)']=VMCount | project Value=['Count (Virtual Machines)'], TypeData='CountVMs', Vertical='Merchant'" | ConvertTo-Json
Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonKPIs)) -logType $logType

Write-Output "Count of SQL databases"
$jsonKPIs=Search-AzGraph "Resources | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | project SubName=name, subscriptionId) on subscriptionId | where  SubName matches regex @'^pgx' or SubName matches regex @'^ssd' | where type == 'microsoft.sql/servers/databases' | summarize Value=count(), TypeData='CountSQLDatabases', Vertical='Merchant'" | ConvertTo-Json
Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonKPIs)) -logType $logType

Write-Output "Count of virtual networks (includes classic)"
$jsonKPIs=Search-AzGraph "Resources | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | project SubName=name, subscriptionId) on subscriptionId | where  SubName matches regex @'^pgx' or SubName matches regex @'^ssd' | where type == 'microsoft.network/virtualnetworks' or type == 'microsoft.classicnetwork/virtualnetworks' | summarize Value=count(), TypeData='CountVirtualNetworks', Vertical='Merchant'" | ConvertTo-Json
Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonKPIs)) -logType $logType

Write-Output "Total public IPs"
$jsonKPIs=Search-AzGraph "Resources | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | project SubName=name, subscriptionId) on subscriptionId | where  SubName matches regex @'^pgx' or SubName matches regex @'^ssd' | where type == 'microsoft.network/publicipaddresses' | summarize Value=count(), TypeData='TotalPublicIP', Vertical='Merchant'" | ConvertTo-Json
Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonKPIs)) -logType $logType

Write-Output "Sum of all disk sizes (GB)"
$jsonKPIs=Search-AzGraph "Resources | join kind=inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | project SubName=name, subscriptionId) on subscriptionId | where  SubName matches regex @'^pgx' or SubName matches regex @'^ssd' | where type == 'microsoft.compute/disks' | extend SizeGB = tolong(properties.diskSizeGB) | summarize Value=sum(SizeGB), TypeData='SumAllDiskSize', Vertical='Merchant'" | ConvertTo-Json
Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonKPIs)) -logType $logType