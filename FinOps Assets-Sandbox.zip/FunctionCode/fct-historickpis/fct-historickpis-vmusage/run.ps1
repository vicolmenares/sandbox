 
$startDate="2021-11-14"
$endDate="2021-11-28"
$fileVMList="vmListResult11.csv"
$fileData="data11.csv"
#$sourceVM="FromFile"
$sourceVM="FromQuery"


#if ((test-path $fileData) -like $true)
#{
#    Clear-Content $fileData
#}


$vmlist=@()
$contVM=1
$numVM=0

if ($sourceVM -eq "FromFile")
{
    $vmlist=Import-csv $fileVMList
    $numVM=$vmlist.Length
}
else
{
    if ((test-path $fileVMList) -like $true)
    {
        Clear-Content $fileVMList
    }

    $numVM=Search-AzGraph "Resources | where type == 'microsoft.compute/virtualmachines' | join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,3) in ('gms','gts','pgx','ssd')) | project id,name,subscriptionId) on subscriptionId | project vmName=name, subscriptionName=name1, subscriptionId, resourceGroup | order by subscriptionName asc, vmName asc | summarize value=count()"
    $numVM=$numVM.value

    $numIterations=[math]::Truncate($numVM/1000)+1

    $vmlist=Search-AzGraph "Resources | where type == 'microsoft.compute/virtualmachines' | join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,3) in ('gms','gts','pgx','ssd')) | project id,name,subscriptionId) on subscriptionId | project vmName=name, subscriptionName=name1, subscriptionId, resourceGroup | order by subscriptionName asc, vmName asc" -first 1000
    for ($i=2;$i -le $numIterations;$i++)
    {
        #Write-Output $i
        $tempList=Search-AzGraph "Resources | where type == 'microsoft.compute/virtualmachines' | join kind = inner (ResourceContainers | where type=='microsoft.resources/subscriptions' | where (substring(name,0,3) in ('gms','gts','pgx','ssd')) | project id,name,subscriptionId) on subscriptionId | project vmName=name, subscriptionName=name1, subscriptionId, resourceGroup | order by subscriptionName asc, vmName asc" -first 1000 -skip (($i-1)*1000)
        $vmlist=$vmlist + $tempList
    }

    $vmlist | Export-Csv $fileVMList
}
#exit 1

$results=@()
$startTime="$($startDate)T00:00:00Z"
$endTime="$($endDate)T00:00:00Z"

foreach ($i in $vmlist)  #[0..4]
{
    Write-Output "Processing $contVM of $numVM..."
    $contVM=$contVM+1
    # get VM
    $vmname=$i.VMNAME
    $subscriptionId=$i.SUBSCRIPTIONID
    $subscriptionName=$i.SUBSCRIPTIONNAME
    #$rg=$i.resourceGroup
    Set-AzContext $subscriptionId

    # get Resource Group Name
    $vm=Get-AzVm -Name $vmname
    $rg=$vm.ResourceGroupName
    $vmsize = $vm.HardwareProfile.VmSize
    $vmProperties=Get-AzVMSize -VMName $vm.Name -ResourceGroupName $vm.ResourceGroupName | where{$_.Name -eq $vmsize}
    #Write-Output "Name: $($vmProperties.Name) Cores:$($vmProperties.NumberOfCores) Memory:$($vmProperties.MemoryInMB) "

    # get Percentage CPU Azure Monitor Metric Data
    #$metric=Get-AzMetric -ResourceId "/subscriptions/$subscriptionId/resourceGroups/$rg/providers/Microsoft.Compute/virtualMachines/$vmname"  -StartTime "$startTime" -EndTime "$endTime" -MetricName "Percentage CPU" -DetailedOutput -TimeGrain "1.00:00:00"
    $metricAVG=Get-AzMetric -ResourceId "/subscriptions/$subscriptionId/resourceGroups/$rg/providers/Microsoft.Compute/virtualMachines/$vmname"  -StartTime "$startTime" -EndTime "$endTime" -MetricName "Percentage CPU" -DetailedOutput -TimeGrain "1.00:00:00" -AggregationType 'Average'
    $metricMAX=Get-AzMetric -ResourceId "/subscriptions/$subscriptionId/resourceGroups/$rg/providers/Microsoft.Compute/virtualMachines/$vmname"  -StartTime "$startTime" -EndTime "$endTime" -MetricName "Percentage CPU" -DetailedOutput -TimeGrain "1.00:00:00" -AggregationType 'Maximum'
    
    #RAM Disponible
    $metricMemory=Get-AzMetric -ResourceId "/subscriptions/$subscriptionId/resourceGroups/$rg/providers/Microsoft.Compute/virtualMachines/$vmname"  -StartTime "$startTime" -EndTime "$endTime" -MetricName "Available Memory Bytes" -DetailedOutput -TimeGrain "1.00:00:00" -AggregationType 'Average'
    
    #hours
    $queryRes = "CostLogs_CL " +
        "| where Date_t >= datetime($startDate) and Date_t < datetime($endDate)  " +
        "| where MeterCategory_s == 'Virtual Machines' " +
        "| where ResourceName_s == '$vmname' and SubscriptionId == '$subscriptionId'" +
        "| summarize totHours=sum(Quantity_d) by Date_t " +
        "| order by Date_t asc "
    $hoursList = Invoke-AzOperationalInsightsQuery -WorkspaceId "b5618e86-1ccb-4212-8ba6-e4af4065877a" -Query  $queryRes
    #$hoursList = $hoursList.Results | ConvertTo-Json
    #Write-Output $hoursList

    $data=@()
    $i=0

    foreach ($record in $metricAVG.Data)
    {
        $recorddata=$record | Select-Object @{Name='VirtualMachineName';Expression={$vmname}},`
            @{Name='SubscriptionId';Expression={$subscriptionId}},`
            @{Name='SubscriptionName';Expression={$subscriptionName}},`
            @{Name='resourceGroup';Expression={$rg}},`
            @{Name='vmSize';Expression={$vmProperties.Name}},`
            @{Name='NumberOfCores';Expression={$vmProperties.NumberOfCores}},`
            @{Name='MemoryInMB';Expression={$vmProperties.MemoryInMB}},`
            @{Name='AvailableMemoryBytes';Expression={$metricMemory.Data[$i].Average}},`
            @{Name='DateMeasure';Expression={$record.TimeStamp}},`
            Average,`
            @{Name='Maximum';Expression={$metricMAX.Data[$i].Maximum}},`
            @{Name='UpTimeHours';Expression={"0"}}
        
        if ($metricMemory.Data[$i].Average -eq $null) { $recorddata.AvailableMemoryBytes="0" }
        if ($record.Average -eq $null) { $recorddata.Average="0" }
        if ($metricMAX.Data[$i].Maximum -eq $null) { $recorddata.Maximum="0" }

        foreach ($hourElemnt in $hoursList.Results)
        {
            $dayTemp = (Get-Date $hourElemnt.Date_t).Day
            if ($recorddata.DateMeasure.Day -eq $dayTemp)
            {
                $recorddata.UpTimeHours=$hourElemnt.totHours   
            }
            #Write-Output "Día: $dayTemp"
        }

        $data=$data + $recorddata
        $i=$i+1
    }
    
    $data | Export-Csv $fileData -Append

}
